AGRI INTELLIGENCE — DATABASE UPGRADE

Upload these files into the repository:
- database.py
- schema_notes.md

Do not change TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID.

After upload, run the existing "Agri Intelligence" workflow.
The current Telegram report should continue working; the SQLite database will gain the new farm-management tables.

Next phase: data-entry layer and app screens for animals, milk, feed, inventory, fields, fuel and accounting.
