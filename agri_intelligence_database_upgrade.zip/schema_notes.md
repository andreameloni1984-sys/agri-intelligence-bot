# Agri Intelligence — Database foundation

This package preserves the existing market/grant tables and adds the foundation for the farm-management app.

New areas:
- farm
- animals (including photo path and present/new recruit/sold/dead/culled status)
- animal_events
- milk_production
- feed_consumption
- inventory and inventory_movements
- fields and field_crops
- hay_production
- fuel_consumption
- financial_transactions

Design principle:
record an event once, then derive stock, costs, production and margins from it.

Example:
feed purchase -> inventory -> daily consumption -> feed cost -> milk cost/litre -> farm margin.

No Telegram token, password, API key or secret is included.
